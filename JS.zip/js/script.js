const startOrder = () => {
    let divMass = document.getElementById("mass")
    let listMass = ""
    MASS.forEach(product => {
        listMass += `<div class="p-10 my-5 bg-cover bg-center bg-${product.name}">
        <p class="font-bold text-lg text-center">${product.name}</p>
        <p class="text-center">$ ${product.price}</p>

        <p><button
                class="addMass px-2 py-3 m-4 text-white transition-all duration-200 rounded shadow bg-secondary-200 hover:bg-secondary-50 shadow-secondary-400"
                id="m-${product.id}">Elegir masa</button></p>
    </div>`

    })

    divMass.innerHTML = listMass

    registerClickeventMass()
}

const registerClickeventMass = () => {
    const btnAddMass = document.getElementsByClassName("addMass")
    for (const btn of btnAddMass) {
        btn.onclick = selectMass
    }
}

const selectMass = (event) => {
    const massID = event.target.id.split("-")[1]
    const mass = MASS.find(p => p.id == massID)
    PREVIEW.push(mass.name)
    carrito.addCart(mass)
    document.getElementById("massContainer").style.display = "none"
    document.getElementById("sizeContainer").style.display = "block"
    showOrder()
    calculateTotalOrder()
}

const pickSize = () => {
    let divSize = document.getElementById("size")
    let listSize = ""
    SIZE.forEach(product => {
        listSize += `<div class="p-10 my-5 bg-cover bg-center bg-${product.name}">
        <p class="font-bold text-lg text-center">${product.name}</p>
        <p class="text-center">$ ${product.price}</p>

        <p><button
                class="addSize px-2 py-3 m-4 text-white transition-all duration-200 rounded shadow bg-secondary-200 hover:bg-secondary-50 shadow-secondary-400"
                id="s-${product.id}">Elegir tamaño</button></p>
    </div>`
    })
    divSize.innerHTML = listSize

    registerClickeventSize()
}

const registerClickeventSize = () => {
    const btnAddSize = document.getElementsByClassName("addSize")
    for (const btn of btnAddSize) {
        btn.onclick = selectSize
    }
}

const selectSize = (event) => {
    const sizeID = event.target.id.split("-")[1]
    const size = SIZE.find(p => p.id == sizeID)
    PREVIEW.push(size.name)
    carrito.addCart(size)
    document.getElementById("sizeContainer").style.display = "none"
    document.getElementById("specialityContainer").style.display = "block"
    showOrder()
    calculateTotalOrder()
}
const pickSpeciality = () => {
    let divSpeciality = document.getElementById("speciality")
    let listSpeciality = ""
    SPECIALITY.forEach(product => {
        listSpeciality += `<div class="p-10 my-5 bg-cover bg-center bg-${product.name}">
        <p class="font-bold text-lg text-center">${product.name}</p>
        <p class="text-center">$ ${product.price}</p>

        <p><button
                class="addSpeciality px-2 py-3 m-4 text-white transition-all duration-200 rounded shadow bg-secondary-200 hover:bg-secondary-50 shadow-secondary-400"
                id="sp-${product.id}">Elegir especialidad</button></p>
    </div>`
    })
    divSpeciality.innerHTML = listSpeciality

    registerClickeventSpeciality()
}

const registerClickeventSpeciality = () => {
    const btnAddSpeciality = document.getElementsByClassName("addSpeciality")
    for (const btn of btnAddSpeciality) {
        btn.onclick = selectSpeciality
    }
}

const selectSpeciality = (event) => {
    const specialityID = event.target.id.split("-")[1]
    const speciality = SPECIALITY.find(p => p.id == specialityID)
    PREVIEW.push(speciality.name)
    carrito.addCart(speciality)
    document.getElementById("specialityContainer").style.display = "none"
    document.getElementById("question").style.display = "block"

    let buttonRepeat = document.getElementById("repeat")
    buttonRepeat.onclick = () => {
        document.getElementById("question").style.display = "none"
        document.getElementById("massContainer").style.display = "block"
    }

    let buttonFinish = document.getElementById("finish")
    buttonFinish.onclick = () => {
        document.getElementById("question").style.display = "none"
        document.getElementById("thanks").style.display = "block"
    }

    showOrder()
    calculateTotalOrder()
    pushToOrder()
    splicePreview()
}

const showOrder = () => {
    let divOrder = document.getElementById("order")
    let order = ""

    // cart.forEach(product => {
    //     order += `<div class="p-10 my-5 bg-cover bg-center bg-${product.name}">
    //     <p class="font-bold text-lg text-center">${product.name}</p>
    //     <p class="text-center">$ ${product.price}</p></div>`

    // })

    divOrder.innerHTML = order
}

const calculateTotalOrder = () => {
    let sumaTotal = 0

    // cart.forEach(p => sumaTotal += p.price)


    const totalOrder = document.getElementById("totalOrder")
    totalOrder.innerHTML = sumaTotal
}

// const pushToOrder = () => {

//     ORDER.push(new FinishPizza(PREVIEW[0], PREVIEW[1], PREVIEW[2]))


// }
const splicePreview = () => {
    PREVIEW.splice(0, PREVIEW.length)

}


calculateTotalOrder()
startOrder()
pickSize()
pickSpeciality()