class Pizza {
    constructor(obj) {
        this.masa = obj.masa
        this.size = obj.size
        this.price = obj.price
        this.speciality = obj.speciality
        this.ship = obj.ship
    }
}